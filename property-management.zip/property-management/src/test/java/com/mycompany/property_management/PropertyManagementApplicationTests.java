package com.mycompany.property_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
